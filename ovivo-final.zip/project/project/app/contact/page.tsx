import { ContactPage } from '@/components/contact-page';

export default function Page() {
  return <ContactPage lang="de" />;
}
